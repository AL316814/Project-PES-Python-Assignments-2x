#Math- Trigonometric functions
'''22.Read the value x and y from the user and apply all trigonometric functions on these numbers. Note : Refer the tutorial Trigonometric operation table.'''
import math
x=float(input("Enter value of x"))
y=float(input("Enter value of y"))
print "acos(x)=",math.acos(x)
print "asin(x)=",math.asin(x)
print "atan(x)=",math.atan(x)
print "atan2(y,x)=",math.atan2(y,x)
print "cos(x)=",math.cos(x)
print "hypot(x,y)=",math.hypot(x,y)
print "sin(x)=",math.sin(x)
print "tan(x)=",math.tan(x)
print "degrees(x)=",math.degrees(x)
print "radians(x)=",math.radians(x)

