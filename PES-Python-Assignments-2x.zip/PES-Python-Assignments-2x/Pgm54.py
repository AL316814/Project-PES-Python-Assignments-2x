'''54. Write a program to handle the following exceptions in you program.
a) KeyboardInterrupt,
b) NameError
c) ArithmeticError
Note : make use of  Try, except, else: statements.'''

import time

i = 1
try:
    while (i < 5):
        time.sleep(1)
        print i
        i += 1
except KeyboardInterrupt:
    print "KeyboardInterrupt"

try:
    name = input("Enter your name:")
    print "Good Morning " + name
except NameError:  # Enter your name in Quotes else NameError msg will appear
    print "NameError"

try:
    num = 0 / 0
except ArithmeticError:
    print "ArithmeticError"

'''55. Write a program for converting weight from Pound to Kilo grams.
      a) Use assertion for the negative weight.
      b) Use assertion to weight more than 100 KG'''


def PoundToKg(pound):
    try:
        assert (pound >= 0), "Negative weight not allowed"
        return pound * 0.453592
    except AssertionError, exp:
        return exp


print PoundToKg(43)
print PoundToKg(-13)


def PoundToKg(pound):
    try:
        assert (pound >= 100), "Weight should be more than or equal to 100"
        return pound * 0.453592
    except AssertionError, exp:
        return exp


print PoundToKg(56)
print PoundToKg(101)

