'''41 Dictionary and Date & Time Using calendar module perform following operations.
a)print the 2016 calendar with space between months as 10 character.
b) How many leap days between the years 1980 to 2025.
c) Check given year is leap year or not.
d) print calendar of any specified month of the year 2016.
'''
import calendar
#a)
print calendar.calendar(2016,w=2,l=1,c=10)
print "\n"*5
#b)
print "number of leapdays between the years 1980 and 2025 is ",calendar.leapdays(1980,2025)
print "\n"*5

#c)
year=input("Enter the year:")
if calendar.isleap(year):
  print year,"is leap year"
else:
  print year,"is NOT leap year"


print "\n"*5
#d)
month=input("enter the month(between 1 and 12) for 2016:")
print calendar.month(2016,month,w=2,l=1)
