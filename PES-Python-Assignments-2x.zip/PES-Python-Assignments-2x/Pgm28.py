#Strings
'''
28.Write a program to check how many ovals present in the given string.
That is, count the number of " a e i o u" in the given string and print the numbers against each oval.
Example :- "This is Python" Number of total ovals = 3 i = 2 o =1
 '''
myStr=input("Enter the string")
myStr=myStr.lower()
list1=list(myStr)
print myStr
count=0
countA=0
countE=0
countI=0
countO=0
countU=0
for i in list1:
  if i=='a':
    count+=1
    countA+=1
  elif i=='e':
    count+=1
    countE+=1
  elif i=='i':
    count+=1
    countI+=1
  elif i=='o':
    count+=1
    countO+=1
  elif i=='u':
    count+=1
    countU+=1
print"No of total vowels=",count
print "count of A",countA
print "count of E",countE
print "count of I",countI
print "count of O",countO
print "count of U",countU